# GitHub 工具发现、写入与 CI 检查手册

## 1. 先判断是什么 GitHub 接入

常见能力分成三类，绝不可混淆：

- **只读 ChatGPT GitHub app/连接器**：可以在授权范围内检索和读取代码；通常不能直接推送文件。要写入，请使用实际有权限的 Codex 工作流、写入型 connector，或让本地智能体在授权 checkout 中执行。
- **写入型 GitHub connector**：可在授权范围内 fetch/create/update/delete 文件、创建分支、创建 commit/PR。每个写工具仍受 GitHub token/App permissions 和分支保护限制。
- **本地仓库执行器**：有实际 checkout，可以运行 `git`、包管理器和测试；本地工作区权限与远端 connector 权限是两套不同能力。

每个新上下文都重新检查工具列表与说明。不能根据历史对话推断本轮存在同样的连接器。

## 2. 典型工具映射（按本轮运行环境的语义描述，不保证其他环境名称相同）

| 需要完成的事 | 查找的工具/接口语义 | 必要检查 |
|---|---|---|
| 读文件 | `fetch_file` / get contents | repo、path、ref；记住 blob SHA |
| 查看提交 | `fetch_commit` / list commits | commit SHA、提交链接、diff |
| 搜索代码 | `search` / code search | 搜索结果只作为定位线索，重要文件用完整读取 |
| 建分支 | `create_branch` | 从当前准确 HEAD SHA 建立 |
| 新建文件 | `create_file` | 确认路径不存在，明确写入 branch |
| 更新文件 | `update_file` | 用刚读取到的内容 blob SHA；完整传入新内容和 branch |
| 删除文件 | `delete_file` | 先确认依赖引用，再传入当前 blob SHA 和 branch |
| 读 Actions | REST `GET /repos/{owner}/{repo}/actions/runs?branch={branch}&per_page=...` | 比较 `head_sha`，状态和结论分开读 |
| 读 jobs/steps | `GET .../actions/runs/{run_id}/jobs` | 找失败的 step，不只看 job 标题 |
| 读日志 | `GET .../actions/jobs/{job_id}/logs` | 读取真实日志尾部和失败断言 |
| 读 artifacts | `GET .../actions/runs/{run_id}/artifacts` | 验证 artifact 所属 run 和 `expired` |
| 重跑失败步骤 | rerun failed jobs（可选） | 必须有 Actions write 权限；重跑不修复源码缺陷 |

接口名称和具体参数以当前工具 schema 为准，不得照表臆造参数。

## 3. 写入 API 的安全规则

1. 每个文件读取一次最新版本；保留当前 blob SHA。
2. 更新时写到显式的目标分支；省略 `branch` 可能写到默认分支，必须避免这种默认行为。
3. 内容更新是整文件替换时，必须基于刚读取的完整源文件修改，绝不可只提交片段。
4. 在同一分支多文件操作时串行推进并在每个关键写入后校验。一个提交推动 HEAD 后，要重新查最新 HEAD 和后续文件 blob SHA。
5. 同一路径绝不并行更新和删除。遇到 SHA 冲突，先重读并比对用户的新改动，不要盲重试。
6. 对破坏性改动，归档分支必须指向旧 HEAD，而不是已经被修改的 HEAD。
7. 删除文件前搜索静态和动态导入、HTML `<script>` 引用、测试、工作流与文档链接。
8. 不读取或显示 Personal Access Token、App private key、Actions secrets、环境密钥；需要授权时引导用户在官方 UI 授权，不让用户把 Secret 粘贴进聊天。

## 4. Actions 判断规则

状态机通常会见到：`queued`、`in_progress`、`completed`；`conclusion` 可能是 `success`、`failure`、`cancelled`、`skipped` 等。

**只有 `status=completed` 且 `conclusion=success` 才能报告该次 workflow 通过。**

最少核对：

- workflow 的 `head_branch` 是目标分支；
- `head_sha` 等于想验证的提交；
- 所有与任务相关的 workflow 都已到终态；
- build、unit/domain、browser/Playwright 相关 step 的状态；
- 出错时取 job logs 找具体断言、堆栈与失败位置；
- 最后一次修复提交之后有新的 run，且它成功。

若工具只显示最近几条运行记录，按 `per_page` 或分页参数继续查看。不要拿之前绿色 SHA 的 run 替代最新 SHA。

## 5. 用 GitHub connector 改动与本地验证的边界

写入型 connector 能把源文件 commit 到分支，但通常**不会**因此在本地启动游戏或直接执行 `npm test`。执行方式取决于项目自动化：

- GitHub Actions push trigger 已执行：从 run 里确认该 SHA 的构建和测试结论；
- 有 Codex/本地执行器：checkout 目标分支后运行项目命令；
- 两者都没有：将自动化测试加入仓库并告知用户需要有权限的 runner/本地代理执行，不宣称已跑过。
