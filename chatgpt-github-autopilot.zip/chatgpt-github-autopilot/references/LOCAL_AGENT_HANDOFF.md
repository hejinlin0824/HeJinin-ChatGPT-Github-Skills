# ChatGPT 提交后的本地智能体交接流程

目标：让用户电脑上的 Claude Code、Codex CLI、Cursor、Copilot 或其他能访问本地 Git 的智能体，安全地拿到 ChatGPT 已提交的远端分支，并继续本地验证。工具名不限，命令以标准 Git 为准。

## ChatGPT 最终回复需要提供什么

```text
Repository: OWNER/REPO
Branch: dev (or actual work branch)
Base SHA: <starting HEAD>
Final SHA: <exact full HEAD SHA>
Commit(s): <links>
CI: <workflow links + conclusions + tested SHA>
Main branch changed: no (unless explicitly authorized)
Known gaps: <none / exact list>
```

不要只给短 SHA。最终 HEAD 必须是分支当前实际指向的提交。

## 推荐的本地操作步骤

先检查本地工作区，避免覆盖未提交内容：

```bash
git status --short --branch
git remote -v
```

确保 remote 指向目标仓库后获取远端信息：

```bash
git fetch origin --prune
git log --oneline --decorate -8 origin/dev
```

切换到现有本地分支时先检查它是否含有需要保留的本地提交。如果只是审查远端变更，建议从远端分支开一个工作分支：

```bash
git switch --create review/chatgpt-dev origin/dev
```

若本地 `review/chatgpt-dev` 已存在，不要覆盖；改用新的名字或先检视该分支。

对照 ChatGPT 报告的最终 SHA：

```bash
git rev-parse origin/dev
git show --stat --oneline <FINAL_SHA>
git diff <BASE_SHA>..<FINAL_SHA> --
```

如需将这些变更并入本地正在工作的 feature 分支，应由本地智能体先检查本地未提交改动、共同祖先和冲突，再决定 merge/cherry-pick/rebase。不能把 `git pull` 无脑运行在用户当前工作分支上。

## 可以直接交给本地智能体的任务提示词

```text
请先读取 git status，不要覆盖或清理我的未提交改动。
从 origin fetch ChatGPT 提交的分支 <BRANCH>，核对远端 HEAD 是否是 <FINAL_SHA>。
先检查 <BASE_SHA>..<FINAL_SHA> 的 diff 和提交说明，阅读 AGENT.md/AGENTS.md 与相关测试。
不要修改 main，不要擅自 merge/rebase/force-push。
在一个独立本地分支上运行项目文档声明的真实测试命令，包括构建、单元/领域测试、浏览器端到端测试（如果已配置）。
检查控制台错误、HTTP 失败、存档持久化和截图。若失败，定位具体根因并向我汇报，不要静默删掉失败断言。
最后给出本地 HEAD、测试命令与结论、失败日志位置以及与远端是否一致。
```

## 本地验证反馈回路

- 若本地验证发现代码缺陷，把具体失败测试、日志、复现步骤和 `git diff` 提交给 ChatGPT；不要只说“跑不过”。
- ChatGPT 在远端工作分支修复并提交后，本地再次 `fetch`，检查新的 SHA 和 diff，再测试。
- 当本地代理生成修复提交时，不要让它直接推到 `dev`，除非用户明确允许并已检查本地分支和推送目标。
- 不共享 PAT、SSH 私钥、App secrets 或 `.env`；如果要让本地代理拉私有仓库，应通过本机 Git credential manager、SSH agent 或组织批准的登录流程授权。
