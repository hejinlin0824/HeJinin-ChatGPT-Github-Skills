# 项目配置：HERO / 2ddoll-game

> 本文件是本 Skill 的项目专属配置示例。对其他仓库使用前，必须更换其中的值；配置是启动线索，执行时仍要从 GitHub 查询最新事实。

## 仓库与分支

- Repository: `hejinlin0824/2ddoll-game`
- GitHub URL: https://github.com/hejinlin0824/2ddoll-game
- 工作分支：`dev`
- 保护约定：未经用户明确授权，不修改 `main`，不把 `dev` 自动合并到 `main`，不 force-push。
- 项目权威指南：仓库里的 `AGENT.md`（同时检查是否存在 `AGENTS.md`）。修改前必须读取当前分支最新版本。
- 项目包含 HTML5 / JavaScript / Canvas2D 游戏，并使用真实浏览器测试；不要只验证设计器静态 HTML。

## 获取代码前必须检查

1. `AGENT.md` / `AGENTS.md`
2. `README.md`
3. `package.json` 和 `.github/workflows/*.yml`
4. 本次任务涉及的源文件及测试
5. 远端 `dev` 最新 HEAD、相关提交、最新 Actions runs

项目测试入口需以当前 `package.json` 为准；历史上存在 `tests/*.test.mjs` 领域测试、`tests/browser-smoke.mjs` Playwright 浏览器流程，以及开发冒烟/外观与装备对齐工作流，执行前确认它们仍存在和当前实现一致。

## 典型 E2E 方向

按本次需求选择覆盖项，不是每项需求都要重复全套：

- 游戏页面实际渲染、控制台与资源请求无错误；
- 波次调度、运输机载荷卸载与生命周期；
- 真实敌人护甲先吸收伤害、耐久耗尽、击杀事件、战利品生成；
- 货币掉落拾取、尸体搜刮、背包分解、商店购买、刷新后持久化；
- Canvas2D 外观预览变化、保存/应用、游戏页真实 Player 加载同一套配置；
- 不同照明状态的固定视口截图和局部区域像素分析；
- UI 覆层关闭/开启动作必须确定完成，不能把主菜单截图误作游戏内角色预览。

如果功能不相关，可省略；若用户指定“端到端/完整回归”，要明确覆盖链路和漏测项。

## 当前已知操作记录（历史快照，并非当前状态判断）

- 曾建立旧皮肤系统归档分支：`archive/skin-system-before-redesign-2026-10-23`。
- 本次 Skill 创建时记录的工作提交参考：`55f52ed60bcd0ba94614382e4bbc80e57de40e9c`。请每次启动重新查询 `dev`，绝不能把这个 SHA 假定为未来 HEAD。
- 相关历史 Actions：
  - Dev smoke checks: https://github.com/hejinlin0824/2ddoll-game/actions/runs/39971847743
  - Appearance and Equipment Alignment: https://github.com/hejinlin0824/2ddoll-game/actions/runs/39971847828
- Skill 编写时 Dev smoke run 显示成功；外观专项 run 曾处于执行中。换上下文或未来使用时，必须重新读取 Actions 最新状态，不能沿用这里的结果。

## 改动后的交接要求

最终向用户提供：目标分支、完整 HEAD SHA、相关 commit URL、对应新 SHA 的 CI URL 与结论、测试覆盖内容/缺口，以及 `git fetch origin` 后让本地智能体安全审查的命令。不要触碰 `main`。
