# 交付报告模板

## 完成内容
- <按验收标准写清用户可见行为变化>
- <兼容性、存档、文档变化>

## GitHub 记录
- Repo: `<owner/repo>`
- Branch: `<branch>`
- Base SHA: `<full SHA>`
- Final HEAD SHA: `<full SHA>`
- Commits: <链接列表>
- Archive branch (if created): `<name>` — source SHA `<full SHA>`

## 验证
| 验证层 | 结论 | 实际依据 |
|---|---|---|
| 单元/领域测试 | 通过/失败/未运行 | 命令或 workflow step + SHA |
| 构建 | 通过/失败/未运行 | 日志/链接 |
| 浏览器 smoke | 通过/失败/未运行 | run URL、page errors、failed requests |
| 端到端 | 通过/失败/未运行 | 真实流程和断言摘要 |
| 视觉回归 | 通过/差异/未运行 | 截图/artifact + 视口/状态 |
| GitHub Actions | success/failure/cancelled/in progress | run URL + `head_sha` |

## 本地智能体交接
```bash
git status --short --branch
git fetch origin --prune
git log --oneline --decorate -8 origin/<branch>
git show --stat --oneline <FINAL_SHA>
git diff <BASE_SHA>..<FINAL_SHA> --
```

## 未做/风险
- <不能执行、未覆盖或明确未授权的操作>
