# ChatGPT ↔ GitHub Autopilot Agent Skill

这是一个适用于兼容 Agent Skills 开放格式的可移植 Skill，用于在 ChatGPT 对话上下文中完成“读 GitHub → 修改工作分支 → 自动化/E2E → 读 CI → 修复 → 交给本地智能体拉取”的研发闭环。

## 文件结构

```text
chatgpt-github-autopilot/
├── SKILL.md                         # 必需的 Skill 主说明
├── README.md                        # 安装与使用
├── LICENSE                          # MIT
├── references/
│   ├── GITHUB_WORKFLOW.md           # 授权能力辨别、写入与 CI 诊断
│   ├── LOCAL_AGENT_HANDOFF.md       # 本地 Git 与其他智能体的安全交接
│   └── PROJECT_PROFILE.md           # 当前 HERO / 2ddoll-game 项目配置示例
└── templates/
    └── FINAL_REPORT.md              # 完成报告模板
```

## 安装

将此目录放进目标智能体支持的 Skill 目录中，并确认该客户端支持开放 Agent Skills 目录结构。常见的跨工具约定是 `.agents/skills/chatgpt-github-autopilot/`；具体安装位置以客户端当前文档为准。

项目本地安装（Git 仓库根目录）示例：

```bash
mkdir -p .agents/skills
cp -R chatgpt-github-autopilot .agents/skills/
```

若下载的是 zip，先解压，然后把 `chatgpt-github-autopilot` 文件夹复制到目标目录。不要仅把 `SKILL.md` 改名成提示词就期待它自动获得工具权限。

## 使用方式

在新上下文中附加/启用 Skill 后，可以直接说：

> 请按此 Skill 继续处理 `hejinlin0824/2ddoll-game` 的 `dev` 分支：先读取最新 AGENT.md 和 HEAD，再实现下面的改动，补测试，检查 GitHub Actions，并给我本地智能体的安全拉取指令：<本次任务>。

它会先检查当前可用的 GitHub 读写工具和 CI 能力。若本轮无写权限，应转为读取/分析并明确说明阻塞，不会假报提交成功。

## 本地校验

Skill 包含一个无需第三方依赖的基础校验脚本：

```bash
python scripts/validate_skill.py
```

它检查主文件 frontmatter、命名规则、文件结构和本地引用。它是轻量级离线检查，不替代官方 `skills-ref validate`。

## 关于权限的关键说明

Skill 只提供流程与规则，不附带 GitHub token。用户需要在 ChatGPT / Codex / 本地开发代理所在产品里正确登录并授权相应仓库；GitHub App 连接范围和权限决定能否读、写或触发 Actions。官方说明：https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt。

## 规范来源

目录结构和 `SKILL.md` frontmatter 按开放 Agent Skills 格式组织：https://agentskills.io/specification。可用官方参考工具执行更完整格式校验：`skills-ref validate ./chatgpt-github-autopilot`。
