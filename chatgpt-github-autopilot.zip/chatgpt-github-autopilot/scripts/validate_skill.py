#!/usr/bin/env python3
"""Lightweight offline checks for this Agent Skill bundle (stdlib only)."""
from __future__ import annotations

import re
import sys
from pathlib import Path


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    skill_path = root / "SKILL.md"
    if not skill_path.is_file():
        fail("SKILL.md is missing")

    content = skill_path.read_text(encoding="utf-8")
    if not content.startswith("---\n"):
        fail("SKILL.md must start with YAML frontmatter")
    parts = content.split("---", 2)
    if len(parts) < 3:
        fail("YAML frontmatter closing delimiter is missing")
    frontmatter, body = parts[1], parts[2]

    name_match = re.search(r"^name:\s*([^\s#]+)\s*$", frontmatter, re.MULTILINE)
    description_match = re.search(r"^description:\s*(.*?)\s*$", frontmatter, re.MULTILINE)
    if not name_match or not description_match:
        fail("frontmatter requires name and description")
    name, description = name_match.group(1), description_match.group(1).strip('"\'')
    if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?", name):
        fail("name must use lowercase letters, numbers and internal hyphens (max 64 chars)")
    if len(description) > 1024 or not description:
        fail("description must be non-empty and at most 1024 characters")
    if len(content.splitlines()) > 500:
        fail("SKILL.md exceeds the recommended 500-line limit")

    # Check local markdown links only; external URLs and in-page anchors are skipped.
    links = re.findall(r"\[[^\]]+\]\(([^)]+)\)", body)
    missing = []
    for target in links:
        target = target.strip()
        if target.startswith(("https://", "http://", "mailto:", "#")):
            continue
        relative = target.split("#", 1)[0]
        if relative and not (root / relative).exists():
            missing.append(target)
    if missing:
        fail("missing local references: " + ", ".join(missing))

    required = [
        "README.md",
        "LICENSE",
        "references/GITHUB_WORKFLOW.md",
        "references/LOCAL_AGENT_HANDOFF.md",
        "references/PROJECT_PROFILE.md",
        "templates/FINAL_REPORT.md",
    ]
    absent = [path for path in required if not (root / path).is_file()]
    if absent:
        fail("missing required bundle files: " + ", ".join(absent))

    print(f"PASS: {name}")
    print(f"- SKILL.md lines: {len(content.splitlines())}")
    print(f"- description characters: {len(description)}")
    print(f"- checked local links: {len(links)}")
    print(f"- bundle root: {root}")


if __name__ == "__main__":
    main()
